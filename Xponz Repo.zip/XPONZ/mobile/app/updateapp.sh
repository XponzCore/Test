#!/bin/sh
cd wallet
rm -rf www
cp -a ../../../html/www www
cd ..
