# Generated

This cryptocurrency has been generated with CoinGenerator - https://coingenerator.sh
